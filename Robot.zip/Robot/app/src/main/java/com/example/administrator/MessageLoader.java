package com.example.administrator;

import android.content.AsyncTaskLoader;
import android.content.Context;

public class MessageLoader extends AsyncTaskLoader<Message> {

    private static final String LOG_TAG = MessageLoader.class.getName();
    //query url
    private String url;

    public MessageLoader(Context context, String url) {
        super(context);
        this.url = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public Message loadInBackground() {
        if (url == null) {
            return null;
        }
        Message message = QueryUtils.fetchMessageData(url);
        return message;
    }
}
