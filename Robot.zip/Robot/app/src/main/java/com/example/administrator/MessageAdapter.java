package com.example.administrator;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class MessageAdapter extends ArrayAdapter<Message> {

    public MessageAdapter(Context context, List<Message> messages) {
        super(context, 0, messages);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listItemView = convertView;

        Message currentMessage = getItem(position);

        if (currentMessage.isMe()) { // i am speaking
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.my_list_item, parent, false);
        } else { // robot speaking
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.robot_list_item, parent, false);
        }

        TextView time = (TextView) listItemView.findViewById(R.id.time_text);
        time.setText(currentMessage.getTime());
        TextView content = (TextView) listItemView.findViewById(R.id.content_text);
        content.setText(Html.fromHtml(currentMessage.getContent()).toString());

        return listItemView;
    }
}
