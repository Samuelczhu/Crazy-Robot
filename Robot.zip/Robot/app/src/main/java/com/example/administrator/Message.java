package com.example.administrator;

public class Message {

    private String content;
    private String time;
    private boolean isMe;

    public Message(boolean isMe, String content, String time) {
        this.content = content;
        this.time = time;
        this.isMe = isMe;
    }

    public Message() {}

    //getters
    public String getContent() {
        return content;
    }

    public String getTime() {
        return time;
    }

    public boolean isMe() {
        return isMe;
    }

    //setters

    public void setContent(String content) {
        this.content = content;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setMe(boolean me) {
        isMe = me;
    }
}
