package com.example.administrator;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Message> {

    private String url;
    MessageAdapter messageAdapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.list);
        messageAdapter = new MessageAdapter(this, new ArrayList<Message>());

        listView.setAdapter(messageAdapter);
        listView.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);

        Date currentTime = Calendar.getInstance().getTime();
        String time = currentTime.toString();
        messageAdapter.add(new Message(false, getString(R.string.hello), time));

        //start the listener
        Button sendButton = (Button) findViewById(R.id.send_button);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                if (networkInfo != null && networkInfo.isConnected()) {
                    EditText input = (EditText) findViewById(R.id.question_input);
                    String inputText = input.getText().toString();
                    input.setText("");//clear the input

                    Date currentTime = Calendar.getInstance().getTime();
                    String time = currentTime.toString();

                    messageAdapter.add(new Message(true, inputText,time));

                    //setting the url
                    url = "http://api.qingyunke.com/api.php?key=free&appid=0&msg="+inputText;

                    LoaderManager loaderManager = getLoaderManager();
                    loaderManager.restartLoader(1, null, MainActivity.this);
                } else {
                    Toast.makeText(getApplicationContext(), getString( R.string.no_internet), Toast.LENGTH_LONG).show();
                }
            }
        });

        Button clearButton = (Button) findViewById(R.id.clear_button);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                messageAdapter.clear();
            }
        });
    }

    @Override
    public Loader<Message> onCreateLoader(int id, Bundle args) {
        return new MessageLoader(this, url);
    }

    @Override
    public void onLoadFinished(Loader<Message> loader, Message data) {
        if (data != null) {
            messageAdapter.add(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<Message> loader) { }
}
